import random

num1 = 1
num2 = 2
operator =['-', '+', '*']
sign = random.sample(operator, 1)
num = eval(str(num1) + ''.join(sign) + str(num2))
temp = str(num1) + ' ' + ''.join(sign) + ' ' + str(num2)
t2 = eval(temp)
print(num)
print(temp)
print(t2)
