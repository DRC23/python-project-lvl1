#!/usr/bin/env python3
from brain_games.games.brain_progression_logic import progression


def main():
    progression()


if __name__ == '__main__':
    main()
